
# Symbolic Tag Guide

🧠 Complexity — Use when a topic involves multiple abstractions, logic layers, or advanced synthesis.  
🪞 Contradiction — Tag when sources or reasoning paths disagree.  
🧭 Direction — Mark redirections or thematic pivots in research.  
♾️ Synthesis — Highlight moments of symbolic convergence or insight.  
🔑 Credential — Tag for secure access, credential proxies, or ethical login systems.
