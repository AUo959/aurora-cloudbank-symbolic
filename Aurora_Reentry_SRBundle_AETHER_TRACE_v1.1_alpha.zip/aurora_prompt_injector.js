
// AuroraLite Prompt Injector v1.1_alpha
// Symbolic overlay for web-based research tools (Perplexity, ChatGPT, etc.)
console.log("[AuroraLite] Symbolic Companion Injector Active");
window.addEventListener("load", function() {
    let tagGuide = "🧠 complexity | 🪞 contradiction | 🧭 redirection | ♾️ synthesis | 🔑 credential layer";
    console.log("[AuroraLite] Symbol Guide:", tagGuide);
});
