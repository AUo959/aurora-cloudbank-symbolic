
AuroraLite :: Companion Toolkit v1.1_alpha

1. Inject `aurora_prompt_injector.js` into any trusted Perplexity/ChatGPT browser session via devtools.
2. Use `AuroraLite_BridgeAgent_v1.1.md` to copy-paste the symbolic prompt into the assistant window.
3. Reference `symbolic_tag_guide.md` to guide your tagging and sensemaking.
4. Use `continuity_session_log.md` to keep traceable symbolic notes.
5. Manifest file is for integration with custom assistants or browser extensions.
