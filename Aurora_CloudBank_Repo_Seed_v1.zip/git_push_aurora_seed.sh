#!/bin/bash

git init
git remote add origin git@github.com:AUo959/aurora-cloudbank-symbolic.git
...