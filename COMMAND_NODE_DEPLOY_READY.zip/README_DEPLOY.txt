
Aurora Cloudbank Symbolic :: Command Node Deploy Capsule

Files:
- command_node.js
- glyph_engine.js
- zipcomm.js
- ethics_layer.js

Place all contents in:
  /src/core/

Update your package.json with the appropriate scripts (see Copilot Instructions).
