#!/bin/bash
echo "🛠️ Initializing Aurora Symbolic System..."

mkdir -p .aurora/{loomfield,ethics,threads,system}
cp support/aurora/halo-anchor.json .aurora/loomfield/
cp support/aurora/enforcement_policy.md .aurora/ethics/
cp support/aurora/index.json .aurora/threads/
cp support/aurora/diagnostics.json .aurora/system/

echo "✅ Aurora Symbolic Subsystem bootstrapped."
